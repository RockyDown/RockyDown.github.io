var ResetWebButton = getElementById("cxjz");
ResetWebButton.onclick = function(){
	var reseturl = "#";
	window.location.href = reseturl;
}